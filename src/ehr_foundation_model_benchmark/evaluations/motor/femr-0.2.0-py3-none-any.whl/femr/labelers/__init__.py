"""A module for generating labels on subject timelines."""

from __future__ import annotations

from femr.labelers.core import *  # noqa
