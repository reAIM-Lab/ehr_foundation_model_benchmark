"""A collection of common ETL pipelines."""
