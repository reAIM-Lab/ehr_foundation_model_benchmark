label_names = ['death', 'long_los']

database_path = "/share/pi/nigam/mwornow/meds_dev_reader"