from typing import List, Dict, Optional
import torch
from transformers import DataCollatorForLanguageModeling
from corebehrt.data.mask import ConceptMasker


def sample_packing_collate_fn(
        examples: List[Dict],
        max_tokens_per_batch: int,
        max_position_embeddings: int,
        concept_masker: Optional[ConceptMasker] = None,
) -> Dict[str, torch.Tensor]:
    """
    :param examples:
    :param max_tokens_per_batch:
    :param max_position_embeddings:
    :return:
    """
    # Main inputs
    current_input_ids = torch.tensor([], dtype=torch.int64)
    current_target = torch.tensor([], dtype=torch.int64)
    current_attention_mask = []
    current_ages = []
    current_abspos = []
    current_segments = []
    current_person_ids = []
    for idx, example in enumerate(examples):
        # If the sample length exceeds the model's capacity, truncate this example
        if len(example["input_ids"]) > max_position_embeddings:
            example["input_ids"] = example["input_ids"][:max_position_embeddings]
            example["attention_mask"] = example["attention_mask"][:max_position_embeddings]
            example["age"] = example["age"][:max_position_embeddings]
            example["abspos"] = example["abspos"][:max_position_embeddings]
            example["segment"] = example["segment"][:max_position_embeddings]

        if concept_masker:
            masked_concepts, target = concept_masker.mask_patient_concepts(
                torch.tensor(example["input_ids"], dtype=torch.long)
            )
        else:
            masked_concepts = torch.tensor(example["input_ids"], dtype=torch.long)
            target = masked_concepts.clone()
        # We add the flattened example to the list either when the example exceeds the total max tokens
        # we add the length by 1 because we need to add one   .... [-100] ......
        current_input_ids = torch.concat(
            [
                current_input_ids,
                masked_concepts,
                torch.tensor([0], dtype=torch.int64),
            ], dim=0
        )
        current_target = torch.concat(
            [
                current_target,
                target,
                torch.tensor([-100], dtype=torch.int64)
            ], dim=0
        )
        current_attention_mask.extend(example["attention_mask"] + [0])
        current_ages.extend(example["age"] + [0])
        current_abspos.extend(example["abspos"] + [0])
        current_segments.extend(example["segment"] + [0])
        if "person_id" in example:
            current_person_ids.append(example["person_id"])
    assert current_input_ids.shape[0] <= max_tokens_per_batch, (
        f"the sample packed sequence must be less than {max_tokens_per_batch}"
    )
    packed_example = {
        "input_ids": current_input_ids.reshape((1, -1)),
        "attention_mask": torch.tensor([current_attention_mask], dtype=torch.float32),
        "age": torch.tensor([current_ages], dtype=torch.float32),
        "abspos": torch.tensor([current_abspos], dtype=torch.float32),
        "segment": torch.tensor([current_segments], dtype=torch.long),
        "target": current_target.reshape((1, -1)),
    }
    if current_person_ids:
        packed_example["person_id"] = torch.tensor([current_person_ids], dtype=torch.long)
    return packed_example


def dynamic_padding(data: list, concept_masker: ConceptMasker, truncate = None) -> dict:
    if truncate is None:
        max_len = max([len(patient["input_ids"]) for patient in data])
    elif truncate is not None:
        max_len = truncate
        # truncate if longer than max position embeddings
        for patient in data:
            if len(patient["input_ids"]) > truncate:
                for key in patient.keys():
                    if key not in ["person_id", "target"]:
                        patient[key] = patient[key][0:max_len]
    for patient in data:
        if concept_masker is not None:
            masked_concepts, target = concept_masker.mask_patient_concepts(patient["input_ids"])
            patient["input_ids"] = masked_concepts
            patient["target"] = target
        difference = max_len - len(patient["input_ids"])
        for key, values in patient.items():
            if key in ["target"]:
                if isinstance(values, float):  # 0D: For finetuning
                    patient[key] = torch.tensor(values)
                    continue
                elif values.ndim == 1:  # 1D: For normal pretraining
                    filler = torch.ones(difference, dtype=values.dtype) * -100
                    patient[key] = torch.cat((values, filler), dim=0)
            elif key in ["person_id"]:
                patient[key] = torch.tensor(values)
            else:
                filler = torch.zeros(difference, dtype=values.dtype)
                patient[key] = torch.cat((values, filler), dim=0)

    padded_data = {}
    for key in data[0].keys():
        padded_data[key] = torch.stack([patient[key] for patient in data])

    return padded_data


class CustomMLMDataCollatorWithPadding:
    def __init__(self, tokenizer, mlm_probability=0.15):
        self.tokenizer = tokenizer
        self.mlm_collator = DataCollatorForLanguageModeling(
            tokenizer=tokenizer,
            mlm=True,
            mlm_probability=mlm_probability
        )

    def __call__(self, features: list) -> dict:
        # Dynamically determine max sequence length
        max_len = max(len(f["input_ids"]) for f in features)

        padded_batch = {}
        for key in features[0].keys():
            # Prepare a list of padded tensors for each key
            padded_tensors = []
            for f in features:
                values = f[key]
                pad_len = max_len - len(values)

                if isinstance(values, torch.Tensor):
                    values = values.clone()
                else:
                    values = torch.tensor(values)

                if key == "target":
                    if values.ndim == 0:  # scalar float
                        values = values.unsqueeze(0)
                    pad_val = -100
                else:
                    pad_val = 0

                padded = torch.cat(
                    [values, torch.full((pad_len,), pad_val, dtype=values.dtype)],
                    dim=0
                )
                padded_tensors.append(padded)

            padded_batch[key] = torch.stack(padded_tensors)

        # Apply MLM to get labels
        mlm_inputs = self.mlm_collator(
            [{"input_ids": ids} for ids in padded_batch["input_ids"]]
        )

        # Overwrite input_ids and add labels
        padded_batch["input_ids"] = mlm_inputs["input_ids"]
        padded_batch["labels"] = mlm_inputs["labels"]
        # attention_mask is created by the MLM collator and padded to match
        padded_batch["attention_mask"] = mlm_inputs["attention_mask"]

        return padded_batch
