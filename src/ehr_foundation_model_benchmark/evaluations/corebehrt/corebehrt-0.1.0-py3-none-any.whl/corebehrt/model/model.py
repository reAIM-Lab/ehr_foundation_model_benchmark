from typing import Optional, List, Tuple

import torch
import torch.nn as nn
import numpy as np
from torch.nn import functional as F
from transformers.models.bert import modeling_bert
from transformers.modeling_outputs import BaseModelOutputWithPastAndCrossAttentions
from transformers.models.bert.modeling_bert import BertModel, BertForPreTrainingOutput
from transformers.models.roformer.modeling_roformer import (
    RoFormerSinusoidalPositionalEmbedding,
    RoFormerSelfAttention,
    RoFormerLayer,
)
from transformers.utils import is_flash_attn_2_available, logging

from corebehrt.embeddings.ehr import EhrEmbeddings
from corebehrt.model.activations import SwiGLU
from corebehrt.model.heads import FineTuneHead, MLMHead, BiGRU

if is_flash_attn_2_available():
    from flash_attn import flash_attn_func, flash_attn_varlen_func
    from flash_attn.bert_padding import index_first_axis, pad_input, unpad_input  # noqa

logger = logging.get_logger("transformers")


def create_packed_position_ids(attention_mask: torch.Tensor) -> torch.Tensor:
    # Step 1: Mark segment boundaries via cumulative sum over padding (0s)
    segment_ids = (attention_mask == 0).cumsum(dim=-1)

    # Step 2: Mask padded positions
    valid_mask = attention_mask.bool()
    flat_seg_ids = segment_ids[valid_mask]

    # Step 3: Get relative position within each segment
    # Sort indices of valid tokens by segment (stable so preserves order within segment)
    sorted_indices = torch.argsort(flat_seg_ids)
    segment_counts = torch.bincount(flat_seg_ids)
    position_within = torch.cat(
        [torch.arange(c, device=attention_mask.device) for c in segment_counts], dim=0
    )

    # Step 4: Reorder back to original order and reshape into original shape
    inverse_indices = torch.argsort(sorted_indices)
    sorted_position_ids = position_within[inverse_indices]

    position_ids = torch.zeros_like(attention_mask, dtype=torch.long)
    position_ids[valid_mask] = sorted_position_ids
    return position_ids


def create_sample_packing_attention_mask(attention_mask: torch.Tensor) -> torch.Tensor:
    """
    Create a block-diagonal attention mask for packed sequences within a batch.

    Args:
        attention_mask (torch.Tensor): (batch_size, seq_len) binary mask where 1 = token, 0 = padding

    Returns:
        torch.Tensor: (batch_size, seq_len, seq_len) attention mask where entries are 1 if tokens
                      can attend to each other (within same packed segment), 0 otherwise.
    """
    # Step 1: Identify segments within each sample
    cumsum_mask = (attention_mask == 0).cumsum(dim=-1)
    segment_ids = cumsum_mask * attention_mask  # zeros remain zero

    # Step 2: Compare segment IDs pairwise per batch element
    # Shape: (batch_size, seq_len, seq_len)
    attn_matrix = (segment_ids.unsqueeze(2) == segment_ids.unsqueeze(1)).int()

    # Step 3: Mask out padding tokens
    mask = attention_mask.unsqueeze(1) * attention_mask.unsqueeze(2)
    attn_matrix = attn_matrix * mask

    return attn_matrix


def is_sample_pack(attention_mask: torch.Tensor) -> bool:
    """
    Determines whether any sequence in the batch is likely sample-packed.

    A sample-packed sequence is one where there are non-padding (1) tokens
    after a padding (0) token, indicating multiple sequences packed together
    with padding as a separator.

    Args:
        attention_mask (torch.Tensor): A tensor of shape (batch_size, seq_len)
            where 1 indicates a real token and 0 indicates padding.

    Returns:
        bool: True if any sample in the batch is sample-packed, False otherwise.
    """
    nonzero_counts = attention_mask.sum(dim=1)
    max_token_positions = torch.argmax(attention_mask.flip(dims=[1]), dim=1)
    max_indices = attention_mask.shape[1] - 1 - max_token_positions
    return torch.any(nonzero_counts < (max_indices + 1)).item()


def flash_attention_forward(
        query_states,
        key_states,
        value_states,
        attention_mask,
        dropout=0.0,
        softmax_scale=None,
        is_causal=False,
):
    """
    Calls the forward method of Flash Attention - if the input hidden states contain at least one padding token.

    first unpad the input, then computes the attention scores and pad the final attention scores.
    Args:
        query_states (`torch.Tensor`):
            Input query states to be passed to Flash Attention API
        key_states (`torch.Tensor`):
            Input key states to be passed to Flash Attention API
        value_states (`torch.Tensor`):
            Input value states to be passed to Flash Attention API
        attention_mask (`torch.Tensor`):
            The padding mask - corresponds to a tensor of size `(batch_size, seq_len)` where 0 stands for the
            position of padding tokens and 1 for the position of non-padding tokens.
        dropout (`int`, *optional*):
            Attention dropout
        softmax_scale (`float`, *optional*):
            The scaling of QK^T before applying softmax. Default to 1 / sqrt(head_dim)
        is_causal (`bool`, *optional*):
    """
    dtype = query_states.dtype
    batch_size, query_length, n_heads, head_dim = query_states.shape
    query_states = query_states.to(torch.bfloat16)
    key_states = key_states.to(torch.bfloat16)
    value_states = value_states.to(torch.bfloat16)
    # Contains at least one padding token in the sequence
    if attention_mask is not None:
        (
            query_states,
            key_states,
            value_states,
            indices_q,
            cu_seq_lens,
            max_seq_lens,
        ) = upad_input(query_states, key_states, value_states, attention_mask, query_length)

        cu_seqlens_q, cu_seqlens_k = cu_seq_lens
        max_seqlen_in_batch_q, max_seqlen_in_batch_k = max_seq_lens

        attn_output_unpad = flash_attn_varlen_func(
            query_states,
            key_states,
            value_states,
            cu_seqlens_q=cu_seqlens_q,
            cu_seqlens_k=cu_seqlens_k,
            max_seqlen_q=max_seqlen_in_batch_q,
            max_seqlen_k=max_seqlen_in_batch_k,
            dropout_p=dropout,
            softmax_scale=softmax_scale,
            causal=is_causal,
        )
        # (batch, seq_length, n_heads, head_dim)
        attn_output = pad_input(attn_output_unpad, indices_q, batch_size, query_length)
    else:
        attn_output = flash_attn_func(
            query_states,
            key_states,
            value_states,
            dropout,
            softmax_scale=softmax_scale,
            causal=is_causal,
        )
    return attn_output.reshape(batch_size, query_length, n_heads * head_dim).to(dtype)


# Copied from transformers.models.llama.modeling_llama.LlamaFlashAttention2._upad_input
def get_unpad_data(attention_mask):
    # This infers sample packing
    if is_sample_pack(attention_mask):
        # Assume input: attention_mask shape = (batch, seq_len)
        attention_mask = attention_mask.flatten()  # shape: (seq_len,)

        # Compute max_index of the last non-zero element
        nonzero = torch.nonzero(attention_mask, as_tuple=False).flatten()
        max_index = nonzero[-1].item()

        # Pad the truncated attention mask
        padded_attention_mask = F.pad(attention_mask[: max_index + 1], (0, 1), value=0)

        # Indices of all tokens
        indices = torch.nonzero(attention_mask, as_tuple=False).flatten()

        # Find where 0s occur (segment boundaries)
        cumsum_seqlens_in_batch = torch.cumsum(padded_attention_mask, dim=0)[padded_attention_mask == 0]

        # Compute seqlens per segment
        seqlens_in_batch = (cumsum_seqlens_in_batch - F.pad(cumsum_seqlens_in_batch, (1, 0), value=0)[:-1]).to(
            torch.int
        )

        max_seqlen_in_batch = seqlens_in_batch.max().item() if seqlens_in_batch.numel() > 0 else 0
        cu_seqlens = F.pad(cumsum_seqlens_in_batch, (1, 0)).to(torch.int)
    else:
        seqlens_in_batch = attention_mask.sum(dim=-1, dtype=torch.int32)
        indices = torch.nonzero(attention_mask.flatten(), as_tuple=False).flatten()
        max_seqlen_in_batch = seqlens_in_batch.max().item()
        cu_seqlens = F.pad(torch.cumsum(seqlens_in_batch, dim=0, dtype=torch.int32), (1, 0))
    return (
        indices,
        cu_seqlens,
        max_seqlen_in_batch,
    )


def upad_input(query_layer, key_layer, value_layer, attention_mask, query_length):
    indices_k, cu_seqlens_k, max_seqlen_in_batch_k = get_unpad_data(attention_mask)
    batch_size, kv_seq_len, num_key_value_heads, head_dim = key_layer.shape

    key_layer = index_first_axis(
        key_layer.reshape(batch_size * kv_seq_len, num_key_value_heads, head_dim),
        indices_k,
    )
    value_layer = index_first_axis(
        value_layer.reshape(batch_size * kv_seq_len, num_key_value_heads, head_dim),
        indices_k,
    )
    if query_length == kv_seq_len:
        query_layer = index_first_axis(
            query_layer.reshape(batch_size * kv_seq_len, num_key_value_heads, head_dim),
            indices_k,
        )
        cu_seqlens_q = cu_seqlens_k
        max_seqlen_in_batch_q = max_seqlen_in_batch_k
        indices_q = indices_k
    elif query_length == 1:
        max_seqlen_in_batch_q = 1
        cu_seqlens_q = torch.arange(
            batch_size + 1, dtype=torch.int32, device=query_layer.device
        )  # There is a memcpy here, that is very bad.
        indices_q = cu_seqlens_q[:-1]
        query_layer = query_layer.squeeze(1)
    else:
        # The -q_len: slice assumes left padding.
        attention_mask = attention_mask[:, -query_length:]
        query_layer, indices_q, cu_seqlens_q, max_seqlen_in_batch_q = unpad_input(query_layer, attention_mask)

    return (
        query_layer,
        key_layer,
        value_layer,
        indices_q,
        (cu_seqlens_q, cu_seqlens_k),
        (max_seqlen_in_batch_q, max_seqlen_in_batch_k),
    )


class RoFormerSelfFlashAttention(RoFormerSelfAttention):
    # The keyword argument is necessary to bypass the BERT flash attention 2 validation
    def __init__(self, config, position_embedding_type=None):
        super().__init__(config)

    def forward(
        self,
        hidden_states,
        attention_mask=None,
        sinusoidal_pos=None,
        head_mask=None,
        encoder_hidden_states=None,
        encoder_attention_mask=None,
        past_key_value=None,
        output_attentions=False,
    ) -> Tuple[torch.Tensor]:

        dtype = hidden_states.dtype
        query = self.query(hidden_states).to(torch.bfloat16)
        key = self.key(hidden_states).to(torch.bfloat16)
        value = self.value(hidden_states).to(torch.bfloat16)
        # If this is instantiated as a cross-attention module, the keys
        # and values come from an encoder; the attention mask needs to be
        # such that the encoder's padding tokens are not attended to.
        is_cross_attention = encoder_hidden_states is not None
        query_layer = self.transpose_for_scores(query)
        if is_cross_attention and past_key_value is not None:
            # reuse k,v, cross_attentions
            key_layer = past_key_value[0]
            value_layer = past_key_value[1]
            attention_mask = encoder_attention_mask
        elif is_cross_attention:
            key_layer = self.transpose_for_scores(key)
            value_layer = self.transpose_for_scores(value)
            attention_mask = encoder_attention_mask
        elif past_key_value is not None:
            key_layer = self.transpose_for_scores(key)
            value_layer = self.transpose_for_scores(value)
            if sinusoidal_pos is not None:
                if self.rotary_value:
                    query_layer, key_layer, value_layer = self.apply_rotary_position_embeddings(
                        sinusoidal_pos, query, key_layer, value_layer
                    )
                else:
                    query_layer, key_layer = self.apply_rotary_position_embeddings(
                        sinusoidal_pos, query_layer, key_layer
                    )
            key_layer = torch.cat([past_key_value[0], key_layer], dim=2)
            value_layer = torch.cat([past_key_value[1], value_layer], dim=2)
        else:
            key_layer = self.transpose_for_scores(key)
            value_layer = self.transpose_for_scores(value)

        attn_dropout = self.dropout.p if self.training else 0.0
        # Flash Attention forward pass, and expects (batch, seq_length, num_heads, head_dim)
        # We need to convert them back to this format
        attn_output = flash_attention_forward(
            query_layer.permute(0, 2, 1, 3).contiguous(),
            key_layer.permute(0, 2, 1, 3).contiguous(),
            value_layer.permute(0, 2, 1, 3).contiguous(),
            attention_mask,
            attn_dropout,
            softmax_scale=None,
            is_causal=False,
        )
        attn_output = attn_output.to(dtype)
        # The BertLayer expects a tuple
        return (attn_output,)

# This is necessary otherwise BERT flash attention 2 validation will fail
modeling_bert.BERT_SELF_ATTENTION_CLASSES.update({"flash_attention_2": RoFormerSelfFlashAttention})

class SamplePackingRoFormerSinusoidalPositionalEmbedding(nn.Embedding):
    """This module produces sinusoidal positional embeddings of any length."""

    def __init__(self, num_positions: int, embedding_dim: int, padding_idx: Optional[int] = None) -> None:
        super().__init__(num_positions, embedding_dim)

    def _init_weight(self):
        """
        Identical to the XLM create_sinusoidal_embeddings except features are not interleaved. The cos features are in
        the 2nd half of the vector. [dim // 2:]
        """
        n_pos, dim = self.weight.shape
        position_enc = np.array(
            [[pos / np.power(10000, 2 * (j // 2) / dim) for j in range(dim)] for pos in range(n_pos)]
        )
        out = torch.empty(n_pos, dim, dtype=self.weight.dtype, requires_grad=False)
        sentinel = dim // 2 if dim % 2 == 0 else (dim // 2) + 1
        out[:, 0:sentinel] = torch.FloatTensor(np.sin(position_enc[:, 0::2]))
        out[:, sentinel:] = torch.FloatTensor(np.cos(position_enc[:, 1::2]))
        self.weight = nn.Parameter(out, requires_grad=False)

    @torch.no_grad()
    def forward(self, position_ids) -> torch.Tensor:
        return super().forward(position_ids)


class RoFormerEncoder(nn.Module):
    def __init__(self, config):
        super().__init__()
        self.config = config
        # TODO: this is just need for backward compatibility, we really should've used config.max_position_embeddings
        #  in self.embed_positions
        max_tokens_per_batch = getattr(config, "max_tokens_per_batch", config.max_position_embeddings)
        self.embed_positions = RoFormerSinusoidalPositionalEmbedding(
            max_tokens_per_batch, config.hidden_size // config.num_attention_heads
        )
        self.sample_packing_embed_positions = SamplePackingRoFormerSinusoidalPositionalEmbedding(
            max_tokens_per_batch, config.hidden_size // config.num_attention_heads
        )
        self.layer = nn.ModuleList([RoFormerLayer(config) for _ in range(config.num_hidden_layers)])
        self.gradient_checkpointing = False

    def forward(
        self,
        hidden_states,
        attention_mask=None,
        head_mask=None,
        encoder_hidden_states=None,
        encoder_attention_mask=None,
        past_key_values=None,
        use_cache=None,
        output_attentions=False,
        output_hidden_states=False,
        return_dict=True,
    ):
        if self.gradient_checkpointing and self.training:
            if use_cache:
                logger.warning_once(
                    "`use_cache=True` is incompatible with gradient checkpointing. Setting `use_cache=False`..."
                )
                use_cache = False
        all_hidden_states = () if output_hidden_states else None
        all_self_attentions = () if output_attentions else None
        all_cross_attentions = () if output_attentions and self.config.add_cross_attention else None

        # [sequence_length, embed_size_per_head] -> [batch_size, num_heads, sequence_length, embed_size_per_head]
        if attention_mask.dim() == 4:
            original_attention_mask = attention_mask.squeeze()[0:1]
        else:
            original_attention_mask = attention_mask

        if is_sample_pack(original_attention_mask):
            position_ids = create_packed_position_ids(original_attention_mask)
            sinusoidal_pos = self.sample_packing_embed_positions(position_ids)[None, :, :]
        else:
            past_key_values_length = past_key_values[0][0].shape[2] if past_key_values is not None else 0
            # [sequence_length, embed_size_per_head] -> [batch_size, num_heads, sequence_length, embed_size_per_head]
            sinusoidal_pos = self.embed_positions(hidden_states.shape[:-1], past_key_values_length)[None, None, :, :]

        next_decoder_cache = () if use_cache else None
        for i, layer_module in enumerate(self.layer):
            if output_hidden_states:
                all_hidden_states = all_hidden_states + (hidden_states,)

            layer_head_mask = head_mask[i] if head_mask is not None else None
            past_key_value = past_key_values[i] if past_key_values is not None else None

            if self.gradient_checkpointing and self.training:
                layer_outputs = self._gradient_checkpointing_func(
                    layer_module.__call__,
                    hidden_states,
                    attention_mask,
                    sinusoidal_pos,
                    layer_head_mask,
                    encoder_hidden_states,
                    encoder_attention_mask,
                    past_key_value,
                    output_attentions,
                )
            else:
                layer_outputs = layer_module(
                    hidden_states,
                    attention_mask,
                    sinusoidal_pos,
                    layer_head_mask,
                    encoder_hidden_states,
                    encoder_attention_mask,
                    past_key_value,
                    output_attentions,
                )

            hidden_states = layer_outputs[0]
            if use_cache:
                next_decoder_cache += (layer_outputs[-1],)
            if output_attentions:
                all_self_attentions = all_self_attentions + (layer_outputs[1],)
                if self.config.add_cross_attention:
                    all_cross_attentions = all_cross_attentions + (layer_outputs[2],)

        if output_hidden_states:
            all_hidden_states = all_hidden_states + (hidden_states,)

        if not return_dict:
            return tuple(
                v
                for v in [
                    hidden_states,
                    next_decoder_cache,
                    all_hidden_states,
                    all_self_attentions,
                    all_cross_attentions,
                ]
                if v is not None
            )
        return BaseModelOutputWithPastAndCrossAttentions(
            last_hidden_state=hidden_states,
            past_key_values=next_decoder_cache,
            hidden_states=all_hidden_states,
            attentions=all_self_attentions,
            cross_attentions=all_cross_attentions,
        )

class BertEHREncoder(BertModel):
    # Flash Attention 2 support
    _supports_flash_attn_2 = True

    def __init__(self, config):
        super().__init__(config)
        self.embeddings = EhrEmbeddings(config)
        # Activate transformer++ recipe
        config.rotary_value = False
        self.encoder = RoFormerEncoder(config)
        print(f"is_flash_attn_2_available(): {is_flash_attn_2_available()}")
        print(f"config._attn_implementation: {config._attn_implementation}")
        for layer in self.encoder.layer:
            layer.intermediate.intermediate_act_fn = SwiGLU(config)
            if is_flash_attn_2_available() and config._attn_implementation == "flash_attention_2":
                print("Replacing BertEHREncoder self attention with RoFormerSelfFlashAttention")
                layer.attention.self = RoFormerSelfFlashAttention(config)


class BertEHRModel(BertEHREncoder):
    def __init__(self, config):
        super().__init__(config)
        self.loss_fct = nn.CrossEntropyLoss()
        self.cls = MLMHead(config)

    def forward(
            self,
            input_ids: Optional[torch.Tensor] = None,
            attention_mask: Optional[torch.Tensor] = None,
            target: Optional[torch.Tensor] = None,
            segment: Optional[torch.Tensor] = None,
            age: Optional[torch.Tensor] = None,
            abspos: Optional[torch.Tensor] = None,
            token_type_ids: Optional[torch.Tensor] = None,
            position_ids: Optional[torch.Tensor] = None,
            head_mask: Optional[torch.Tensor] = None,
            inputs_embeds: Optional[torch.Tensor] = None,
            encoder_hidden_states: Optional[torch.Tensor] = None,
            encoder_attention_mask: Optional[torch.Tensor] = None,
            past_key_values: Optional[List[torch.FloatTensor]] = None,
            use_cache: Optional[bool] = None,
            output_attentions: Optional[bool] = None,
            output_hidden_states: Optional[bool] = None,
            return_dict: Optional[bool] = None,
    ) -> BertForPreTrainingOutput:

        position_ids = {
            "age": age,
            "abspos": abspos
        }  # abspos

        outputs = super().forward(
            input_ids=input_ids,
            attention_mask=attention_mask,
            token_type_ids=segment,
            position_ids=position_ids,
            head_mask=head_mask,
            inputs_embeds=inputs_embeds,
            encoder_hidden_states=encoder_hidden_states,
            encoder_attention_mask=encoder_attention_mask,
            past_key_values=past_key_values,
            use_cache=use_cache,
            output_attentions=output_attentions,
            output_hidden_states=output_hidden_states,
            return_dict=True,
        )

        sequence_output = outputs.last_hidden_state  # Last hidden state
        logits = self.cls(sequence_output)  # CHANGE , batch['attention_mask']
        outputs.logits = logits

        loss = None
        if target is not None:
            loss = self.get_loss(logits, target)

        return BertForPreTrainingOutput(
            loss=loss,
            prediction_logits=logits,
            hidden_states=outputs.hidden_states,
            attentions=outputs.attentions,
        )

    def get_loss(self, logits, labels):
        """Calculate loss for masked language model."""
        return self.loss_fct(logits.view(-1, self.config.vocab_size), labels.view(-1))

    def get_extended_attention_mask(
        self, attention_mask: torch.Tensor, input_shape: Tuple[int], device: torch.device = None, dtype: torch.float = None
    ) -> torch.Tensor:
        """
        Makes broadcastable attention and causal masks so that future and masked tokens are ignored.

        Arguments:
            attention_mask (`torch.Tensor`):
                Mask with ones indicating tokens to attend to, zeros for tokens to ignore.
            input_shape (`Tuple[int]`):
                The shape of the input to the model.

        Returns:
            `torch.Tensor` The extended attention mask, with a the same dtype as `attention_mask.dtype`.
        """
        if getattr(self.config, "_attn_implementation", "eager") == "flash_attention_2":
            return attention_mask

        if is_sample_pack(attention_mask):
            attention_mask = create_sample_packing_attention_mask(attention_mask)[:, None, :, :]
            # Since attention_mask is 1.0 for positions we want to attend and 0.0 for
            # masked positions, this operation will create a tensor which is 0.0 for
            # positions we want to attend and the dtype's smallest value for masked positions.
            # Since we are adding it to the raw scores before the softmax, this is
            # effectively the same as removing these entirely.
            attention_mask = attention_mask.to(dtype=self.dtype)  # fp16 compatibility
            attention_mask = (1.0 - attention_mask) * torch.finfo(self.dtype).min
            return attention_mask
        else:
            return super().get_extended_attention_mask(attention_mask, input_shape, device, dtype)


class BertForFineTuning(BertEHRModel):
    def __init__(self, config):
        super().__init__(config)

        self.loss_fct = nn.BCEWithLogitsLoss()
        self.cls = FineTuneHead(config)

    def get_loss(self, hidden_states, labels):
        return self.loss_fct(hidden_states.view(-1), labels.view(-1))
