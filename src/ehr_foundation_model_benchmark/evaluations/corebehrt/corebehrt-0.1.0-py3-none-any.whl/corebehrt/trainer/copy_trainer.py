from transformers import Trainer, TrainingArguments, TrainerCallback, EarlyStoppingCallback, TrainerControl, TrainerState
from transformers.trainer_utils import PREFIX_CHECKPOINT_DIR
from torch.utils.data import Dataset
import os
import logging
import numpy as np
import torch
from typing import Dict, Any
import json


from torch.utils.data import Dataset


class CustomEarlyStoppingCallback(EarlyStoppingCallback):
    def check_metric_value(self, args, state, control, metric_value):
        if state.best_metric is not None:
            print(f"Relative improvement: {abs(metric_value - state.best_metric) / state.best_metric}")
        self.early_stopping_threshold = 0.01
        # best_metric is set by code for load_best_model
        operator = np.greater if args.greater_is_better else np.less
        if state.best_metric is None or (
            operator(metric_value, state.best_metric)
            and abs(metric_value - state.best_metric) / state.best_metric > self.early_stopping_threshold
        ):
            self.early_stopping_patience_counter = 0
        else:
            self.early_stopping_patience_counter += 1
            
            
class LossLoggingCallback(TrainerCallback):
    def __init__(self, log_file="loss_log.json"):
        self.log_file = log_file
        self.logs = []

    def on_log(self, args: TrainingArguments, state: TrainerState, control: TrainerControl, logs: Dict[str, float], **kwargs):
        self.logs.append({"step": state.global_step, **logs})
        with open(self.log_file, 'w') as f:
            json.dump(self.logs, f, indent=2)
