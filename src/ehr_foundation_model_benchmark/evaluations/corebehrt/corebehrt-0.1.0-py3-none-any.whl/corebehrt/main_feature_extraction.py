"""Get features extracted for linear probing from pretrained model."""
import os
import pathlib
import uuid
from functools import partial
import numpy as np
import torch
from transformers.utils import is_flash_attn_2_available, logging
from transformers.trainer_utils import get_last_checkpoint
from datasets import Dataset, DatasetDict, load_from_disk, concatenate_datasets
import json
from transformers import AutoConfig, BertConfig
from safetensors.torch import load_file
from torch.utils.data import DataLoader
from tqdm import tqdm
import pandas as pd

os.environ["PYTORCH_CUDA_ALLOC_CONF"] = "expandable_segments:True"
os.environ['CUDA_LAUNCH_BLOCKING'] = "1"
os.environ['TORCH_USE_CUDA_DSA'] = "1"

from corebehrt.common.azure import AzurePathContext
from corebehrt.common.config import load_config
from corebehrt.common.setup import DirectoryPreparer, copy_data_config, get_args
from corebehrt.dataloader.collate_fn import dynamic_padding, sample_packing_collate_fn
from corebehrt.trainer.sample_packing_sampler import SamplePackingBatchSampler
from corebehrt.model.model import BertEHRModel

CONFIG_NAME = 'experiments.yaml'
BLOBSTORE = 'PHAIR'
PREPARED_DATASET_DIR = "prepared_dataset/"

print('Checking flash attention', torch.backends.cuda.flash_sdp_enabled())
print('Checking memory efficient sdp', torch.backends.cuda.mem_efficient_sdp_enabled())
print('Checking math sdp enabled', torch.backends.cuda.math_sdp_enabled())
torch.set_float32_matmul_precision("high")

LOG = logging.get_logger("transformers")




def main(config_path):
    if torch.cuda.is_available():
        device = torch.device("cuda")
    else:
        device = torch.device("cpu")

    cfg = load_config(config_path)
    cfg, run, mount_context = AzurePathContext(cfg, dataset_name=BLOBSTORE).adjust_paths_for_azure_pretrain()

    logger, run_folder = DirectoryPreparer.setup_run_folder(cfg)
    copy_data_config(cfg, run_folder)

    path_cfg = cfg.paths
    tokenized_dir = path_cfg.get('tokenized_dir', 'tokenized')
    tokenized_data_path = os.path.join(path_cfg.data_path, tokenized_dir)
    vocabulary_file_path = path_cfg.get("vocab_path")
    vocab = torch.load(vocabulary_file_path, weights_only=False)
    print('done getting vocab')

    pids_mapping = pd.read_csv(path_cfg.get("data_path") + 'pid_mapping.csv', index_col=0)
    pids_mapping['prediction_time'] = pids_mapping['prediction_time'].astype('datetime64[ns]')

    sample_packing = cfg.get("trainer_args").get("sample_packing", False)
    average_over_sequence = cfg.get("trainer_args").get("average_over_sequence", False)
    output_path = pathlib.Path(cfg.paths.get("output_path"))
    prepared_dataset_path = output_path / PREPARED_DATASET_DIR
    if prepared_dataset_path.exists() and any(prepared_dataset_path.iterdir()):
        prepared_dataset = load_from_disk(str(prepared_dataset_path))
    else:
        data_path = cfg.paths.get("data_path")
        train_dataset = torch.load(tokenized_data_path + 'tokenized_pretrain.pt', weights_only=False)
        train_pids = torch.load(tokenized_data_path + 'pids_pretrain.pt', weights_only=False)
        nested_train_pids = [[i] for i in train_pids]
        train_dataset['person_id'] = nested_train_pids

        val_dataset = torch.load(tokenized_data_path + 'tokenized_finetune.pt', weights_only=False)
        val_pids = torch.load(tokenized_data_path + 'pids_finetune.pt', weights_only=False)
        nested_val_pids = [[i] for i in val_pids]
        val_dataset['person_id'] = nested_val_pids

        test_dataset = torch.load(tokenized_data_path + 'tokenized_test.pt', weights_only=False)
        test_pids = torch.load(tokenized_data_path + 'pids_test.pt', weights_only=False)
        nested_test_pids = [[i] for i in test_pids]
        test_dataset['person_id'] = nested_test_pids

        print('Checking person_id')
        print(test_dataset.keys())
        print(test_dataset['person_id'][0:5])
        print(test_dataset['segment'][0:5])
        print(len(test_dataset['person_id']), len(test_dataset['concept']), len(test_dataset['age']))

        hf_train_dataset = {"input_ids" if k == 'concept' else k: v for k, v in train_dataset.items()}
        hf_train_dataset = Dataset.from_dict(hf_train_dataset)

        LOG.info('train data length hf %s', len(hf_train_dataset))
        LOG.info('train data type %s', type(hf_train_dataset))
        LOG.info("Underlying table size: %s", hf_train_dataset._data.num_rows)
        LOG.info("Indices size: %s", len(hf_train_dataset._indices) if hf_train_dataset._indices else "None")

        hf_val_dataset = {"input_ids" if k == 'concept' else k: v for k, v in val_dataset.items()}
        hf_val_dataset = Dataset.from_dict(hf_val_dataset)

        hf_test_dataset = {"input_ids" if k == 'concept' else k: v for k, v in test_dataset.items()}
        hf_test_dataset = Dataset.from_dict(hf_test_dataset)

        processing_batch_size = cfg.get("data").get("processing_batch_size", 1024)
        num_proc = cfg.get("data").get("num_proc", 8)
        LOG.info("Computing the train sequence lengths")
        hf_train_dataset = hf_train_dataset.map(
            lambda batch: {"num_of_concepts": [len(input_ids) for input_ids in batch["input_ids"]]},
            batched=True,
            batch_size=processing_batch_size,
            num_proc=num_proc
        )
        LOG.info("Computing the validation sequence lengths")
        hf_val_dataset = hf_val_dataset.map(
            lambda batch: {"num_of_concepts": [len(input_ids) for input_ids in batch["input_ids"]]},
            batched=True,
            batch_size=processing_batch_size,
            num_proc=num_proc
        )
        LOG.info("Computing the test sequence lengths")
        hf_test_dataset = hf_test_dataset.map(
            lambda batch: {"num_of_concepts": [len(input_ids) for input_ids in batch["input_ids"]]},
            batched=True,
            batch_size=processing_batch_size,
            num_proc=num_proc
        )

        prepared_dataset = DatasetDict({
            "train": hf_train_dataset,
            "validation": hf_val_dataset,
            "test": hf_test_dataset
        })
        prepared_dataset.save_to_disk(str(prepared_dataset_path))

    if not sample_packing:
        prepared_dataset.reset_format()
        prepared_dataset.set_format(type='torch',
                                    columns=['person_id', 'input_ids', 'age', 'segment', 'abspos', 'attention_mask'])

    inference_set = concatenate_datasets([
        prepared_dataset["train"],
        prepared_dataset["validation"],
        prepared_dataset['test']
    ])

    corebehrt_model = BertEHRModel.from_pretrained(
        path_cfg.get('model_path'),
        attn_implementation=("flash_attention_2" if is_flash_attn_2_available() else None),
    ).eval().to(device)

    max_position_embeddings = cfg.get("trainer_args").get("max_position_embeddings", 2048)
    max_tokens_per_batch = cfg.get("trainer_args").get("max_tokens_per_batch", 16384)
    dataloader_drop_last = cfg.get("trainer_args").get("dataloader_drop_last", False)
    seed = cfg.get("trainer_args").get("seed", 31)
    per_device_eval_batch_size = cfg.get("trainer_args").get("per_device_eval_batch_size", 8)

    if sample_packing:
        per_device_eval_batch_size = 1
        data_collator_fn = partial(
            sample_packing_collate_fn,
            max_tokens_per_batch=max_tokens_per_batch,
            max_position_embeddings=max_position_embeddings,
            concept_masker=None,
        )
        batch_sampler = SamplePackingBatchSampler(
            lengths=inference_set["num_of_concepts"],
            max_tokens_per_batch=max_tokens_per_batch,
            max_position_embeddings=max_position_embeddings,
            drop_last=dataloader_drop_last,
            seed=seed,
        )
    else:
        data_collator_fn = partial(dynamic_padding, concept_masker=None, truncate=max_position_embeddings)
        batch_sampler = None
        per_device_eval_batch_size = per_device_eval_batch_size

    full_loader = DataLoader(
        dataset=inference_set,
        batch_size=per_device_eval_batch_size,
        num_workers=cfg.get("trainer_args").get("dataloader_num_workers", 1),
        collate_fn=data_collator_fn,
        pin_memory=cfg.get("trainer_args").get("pin_memory", False),
        batch_sampler=batch_sampler,
    )

    data_loaders = [("full", full_loader)]

    for split, data_loader in data_loaders:

        # Ensure prediction folder exists
        feature_output_folder = pathlib.Path(output_path) / "features_with_label"
        feature_output_folder.mkdir(parents=True, exist_ok=True)

        LOG.info("Generating features for %s set at %s", split, feature_output_folder)

        with torch.no_grad():
            for index, batch in enumerate(tqdm(data_loader, desc="Generating features")):
                person_ids = batch.pop("person_id").numpy().astype(int).squeeze()
                if person_ids.ndim == 0:
                    person_ids = np.asarray([person_ids])

                batch = {k: v.to(device) for k, v in batch.items()}
                # Forward pass
                corebehrt_output = corebehrt_model(**batch, output_attentions=False, output_hidden_states=True)
                last_hidden_state = corebehrt_output.hidden_states[-1]

                cls_token_indices = batch["input_ids"] == 1
                squeeze_axis = 0 if sample_packing else 1
                # For sample packing, the shape of last_hidden_state: [1, packed_sequence_length, hidden_size], so
                # we squeeze the first dimension. For non sample packing, the shape of last_hidden_state:
                # [bz, context_window, hidden_size], we need to squeeze the second dimension.
                features = last_hidden_state[cls_token_indices, :].squeeze(axis=squeeze_axis)
                features = features.cpu().float().detach().numpy()

                features_list = [feature for feature in features]
                if len(person_ids) == 1:
                    features_list = [features_list]
                features_pd = pd.DataFrame(
                    {
                        "PID_unique": person_ids,
                        "features": features_list
                    }
                )
                features_pd = features_pd.merge(pids_mapping, how='inner', on='PID_unique')
                # Adding features as a separate column where each row contains a feature array
                features_pd.to_parquet(feature_output_folder / f"{uuid.uuid4()}.parquet", engine="pyarrow", index=False)


if __name__ == '__main__':
    args = get_args(CONFIG_NAME)
    # config_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), args.config_path)
    main(args.config_path)
