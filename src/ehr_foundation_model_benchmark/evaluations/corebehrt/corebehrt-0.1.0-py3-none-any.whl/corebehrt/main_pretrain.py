"""Pretrain BERT model on EHR data. Use config_template pretrain.yaml. Run main_data_pretrain.py first to create the dataset and vocabulary."""
import os
import pathlib
from functools import partial
from typing import Optional

import torch
from transformers import Trainer, TrainingArguments
from transformers.utils import is_flash_attn_2_available, logging
from transformers.trainer_utils import get_last_checkpoint
from datasets import Dataset, DatasetDict, load_from_disk

os.environ["PYTORCH_CUDA_ALLOC_CONF"] = "expandable_segments:True"
os.environ['CUDA_LAUNCH_BLOCKING'] = "1"
os.environ['TORCH_USE_CUDA_DSA'] = "1"

from corebehrt.common.azure import AzurePathContext
from corebehrt.common.config import load_config, Config
from corebehrt.common.initialize import Initializer
from corebehrt.common.loader import load_checkpoint_and_epoch
from corebehrt.common.setup import DirectoryPreparer, copy_data_config, get_args
from corebehrt.data.mask import ConceptMasker
from corebehrt.data.prepare_data import DatasetPreparer
from corebehrt.dataloader.collate_fn import dynamic_padding
from corebehrt.trainer.copy_trainer import CustomEarlyStoppingCallback, LossLoggingCallback
from corebehrt.trainer.sample_packing_trainer import SamplePackingTrainer
from corebehrt.dataloader.collate_fn import sample_packing_collate_fn

CONFIG_NAME = 'pretrain.yaml'
BLOBSTORE = 'PHAIR'
PREPARED_DATASET_DIR = "prepared_dataset"

print('Checking flash attention', torch.backends.cuda.flash_sdp_enabled())
print('Checking memory efficient sdp', torch.backends.cuda.mem_efficient_sdp_enabled())
print('Checking math sdp enabled', torch.backends.cuda.math_sdp_enabled())
torch.set_float32_matmul_precision("high")

LOG = logging.get_logger("transformers")


def get_last_hf_checkpoint(training_args):
    """
    Retrieves the path to the last saved checkpoint from the specified output directory,.

    if it exists and conditions permit resuming training from that checkpoint.

    This function checks if an output directory contains any previously saved checkpoints and
    returns the path to the last checkpoint if found. It raises an error if the output directory
    is not empty and overwriting is not enabled, unless explicitly handled by the user to resume
    training or to start afresh by setting the appropriate training arguments.

    Parameters:
        training_args (TrainingArguments): An object containing training configuration parameters, including:
            - output_dir (str): The path to the directory where training outputs are saved.
            - do_train (bool): Whether training is to be performed. If False, the function will not check for checkpoints.
            - overwrite_output_dir (bool): If True, allows overwriting files in `output_dir`.
            - resume_from_checkpoint (str or None): Path to the checkpoint from which training should be resumed.

    Returns:
        str or None: The path to the last checkpoint if a valid checkpoint exists and training is set to resume.
        Returns None if no checkpoints are found or if resuming from checkpoints is not enabled.

    Raises:
        ValueError: If the output directory exists, is not empty, and `overwrite_output_dir` is False,
                    indicating a potential unintended overwriting of training results.

    Example:
        >>> training_args = TrainingArguments(
        ...     output_dir='./results',
        ...     do_train=True,
        ...     overwrite_output_dir=False,
        ...     resume_from_checkpoint=None
        ... )
        >>> last_checkpoint = get_last_hf_checkpoint(training_args)
        >>> print(last_checkpoint)
        '/path/to/results/checkpoint-500'

    Note:
        If `last_checkpoint` is detected and `resume_from_checkpoint` is None, training will automatically
        resume from the last checkpoint unless instructed otherwise via the `overwrite_output_dir` flag or
        by changing the output directory.
    """
    last_checkpoint = None
    output_dir_abspath = os.path.abspath(training_args.output_dir)
    if os.path.isdir(output_dir_abspath) and training_args.do_train and not training_args.overwrite_output_dir:
        last_checkpoint = get_last_checkpoint(output_dir_abspath)
        if last_checkpoint is None and len([_ for _ in os.listdir(output_dir_abspath) if os.path.isdir(_)]) > 0:
            raise ValueError(
                f"Output directory ({output_dir_abspath}) already exists and is not empty. "
                "Use --overwrite_output_dir to overcome."
            )
        elif last_checkpoint is not None and training_args.resume_from_checkpoint is None:
            LOG.info(
                "Checkpoint detected, resuming training at %s. To avoid this behavior, change "
                "the `--output_dir` or add `--overwrite_output_dir` to train from scratch.",
                last_checkpoint,
            )
    return last_checkpoint


def create_concept_mask(cfg: Config) -> ConceptMasker:
    from corebehrt.common.loader import VOCABULARY_FILE
    path_cfg = cfg.paths
    tokenized_dir = path_cfg.get('tokenized_dir', 'tokenized')
    tokenized_data_path = os.path.join(path_cfg.data_path, tokenized_dir)
    vocabulary_file_path = os.path.join(str(tokenized_data_path), VOCABULARY_FILE)
    if not os.path.exists(vocabulary_file_path):
        vocabulary_file_path = os.path.join(path_cfg.data_path, VOCABULARY_FILE)
    vocab = torch.load(str(vocabulary_file_path))
    select_ratio = cfg.data.dataset.get("select_ratio", 0.15)
    masking_ratio = cfg.data.dataset.get("masking_ratio", 0.8)
    replace_ratio = cfg.data.dataset.get("replace_ratio", 0.1)
    ignore_special_tokens = cfg.data.dataset.get("ignore_special_tokens", True)
    return ConceptMasker(
        vocabulary=vocab,
        select_ratio=select_ratio,
        masking_ratio=masking_ratio,
        replace_ratio=replace_ratio,
        ignore_special_tokens=ignore_special_tokens,
    )


def main_train(config_path):
    cfg = load_config(config_path)
    cfg, run, mount_context = AzurePathContext(cfg, dataset_name=BLOBSTORE).adjust_paths_for_azure_pretrain()

    logger, run_folder = DirectoryPreparer.setup_run_folder(cfg)
    copy_data_config(cfg, run_folder)

    sample_packing = cfg.get("trainer_args").get("sample_packing", False)
    output_path = pathlib.Path(cfg.paths.get("output_path"))
    prepared_dataset_path = output_path / PREPARED_DATASET_DIR
    if prepared_dataset_path.exists() and any(prepared_dataset_path.iterdir()):
        prepared_dataset = load_from_disk(str(prepared_dataset_path))
        concept_masker = create_concept_mask(cfg)
    else:
        train_dataset, val_dataset = DatasetPreparer(cfg).prepare_mlm_dataset()
        concept_masker = train_dataset.masker
        hf_train_dataset = {"input_ids" if k == 'concept' else k: v for k, v in train_dataset.features.items()}
        hf_train_dataset = Dataset.from_dict(hf_train_dataset)

        LOG.info('train data length hf %s', len(hf_train_dataset))
        LOG.info('train data type %s', type(hf_train_dataset))
        LOG.info("Underlying table size: %s", hf_train_dataset._data.num_rows)
        LOG.info("Indices size: %s", len(hf_train_dataset._indices) if hf_train_dataset._indices else "None")

        hf_val_dataset = {"input_ids" if k == 'concept' else k: v for k, v in val_dataset.features.items()}
        hf_val_dataset = Dataset.from_dict(hf_val_dataset)

        processing_batch_size = cfg.get("data").get("processing_batch_size", 1024)
        num_proc = cfg.get("data").get("num_proc", 8)
        LOG.info("Computing the train sequence lengths")
        hf_train_dataset = hf_train_dataset.map(
            lambda batch: {"num_of_concepts": [len(input_ids) for input_ids in batch["input_ids"]]},
            batched=True,
            batch_size=processing_batch_size,
            num_proc=num_proc
        )
        LOG.info("Computing the validation sequence lengths")
        hf_val_dataset = hf_val_dataset.map(
            lambda batch: {"num_of_concepts": [len(input_ids) for input_ids in batch["input_ids"]]},
            batched=True,
            batch_size=processing_batch_size,
            num_proc=num_proc
        )
        prepared_dataset = DatasetDict({
            "train": hf_train_dataset,
            "validation": hf_val_dataset
        })
        prepared_dataset.save_to_disk(str(prepared_dataset_path))

    if not sample_packing:
        prepared_dataset.reset_format()
        prepared_dataset.set_format(type='torch', columns=['input_ids', 'age', 'segment', 'abspos', 'attention_mask'])

    checkpoint, epoch = load_checkpoint_and_epoch(cfg)
    logger.info(f'Continue training from epoch {epoch}')
    attn_implementation = "flash_attention_2" if is_flash_attn_2_available() else "eager"
    initializer = Initializer(cfg, checkpoint=checkpoint, attn_implementation=attn_implementation)
    model = initializer.initialize_pretrain_model(concept_masker.vocabulary)
    model_parameters = sum(p.numel() for p in model.parameters())
    logger.info(f'Total parameters: {model_parameters:,}')

    trainable_params = sum(p.numel() for p in model.parameters() if p.requires_grad)
    logger.info(f'Trainable parameters: {trainable_params:,}')
    logger.info('Initialize trainer')

    per_device_train_batch_size = cfg.get("trainer_args").get("per_device_train_batch_size", 8)
    gradient_accumulation_steps = cfg.get("trainer_args").get("gradient_accumulation_steps", 2)
    logging_steps = cfg.get("trainer_args").get("logging_steps", 10)
    label_names = cfg.get("trainer_args").get("label_names", ["target"])
    learning_rate = cfg.get("trainer_args").get("learning_rate", 1e-4)
    dataloader_num_workers = cfg.get("trainer_args").get("dataloader_num_workers", 8)
    dataloader_prefetch_factor = cfg.get("trainer_args").get("dataloader_prefetch_factor", 8)

    training_args = TrainingArguments(
        output_dir=cfg.paths.output_path,
        save_strategy="epoch",
        eval_strategy='epoch',
        warmup_steps=500,
        per_device_train_batch_size=per_device_train_batch_size,
        gradient_accumulation_steps=gradient_accumulation_steps,
        per_device_eval_batch_size=32,
        learning_rate=learning_rate,
        weight_decay=0.01,
        num_train_epochs=20,
        data_seed=31,
        seed=31,
        disable_tqdm=False,
        metric_for_best_model='eval_loss',
        load_best_model_at_end=True,
        logging_steps=logging_steps,
        label_names=label_names,
        do_train=True,
        dataloader_num_workers=dataloader_num_workers,
        dataloader_prefetch_factor=dataloader_prefetch_factor,
    )

    max_position_embeddings = cfg.get("trainer_args").get("max_position_embeddings", 2048)
    max_tokens_per_batch = cfg.get("trainer_args").get("max_tokens_per_batch", 16384)

    if sample_packing:
        trainer_class = partial(
            SamplePackingTrainer,
            max_tokens_per_batch=max_tokens_per_batch,
            max_position_embeddings=max_position_embeddings,
            train_lengths=prepared_dataset["train"]["num_of_concepts"],
            validation_lengths=prepared_dataset["validation"]["num_of_concepts"],
        )
        training_args.per_device_train_batch_size = 1
        training_args.gradient_accumulation_steps = 1
        training_args.per_device_eval_batch_size = 1
        data_collator_fn = partial(
            sample_packing_collate_fn,
            max_tokens_per_batch=max_tokens_per_batch,
            max_position_embeddings=max_position_embeddings,
            concept_masker=concept_masker,
        )
    else:
        trainer_class = Trainer
        data_collator_fn = partial(dynamic_padding, concept_masker=concept_masker)

    trainer = trainer_class(
        model=model,
        args=training_args,
        train_dataset=prepared_dataset["train"],
        eval_dataset=prepared_dataset["validation"],
        callbacks=[
            CustomEarlyStoppingCallback(1, 0.01),
            LossLoggingCallback(log_file=os.path.join(cfg.paths.output_path, "loss_log.json"))
        ],
        data_collator=data_collator_fn
    )

    # Detecting last checkpoint.
    last_checkpoint = get_last_hf_checkpoint(training_args)
    train_result = trainer.train(resume_from_checkpoint=last_checkpoint)
    trainer.save_model()  # Saves the tokenizer too for easy upload
    metrics = train_result.metrics

    trainer.log_metrics("train", metrics)
    trainer.save_metrics("train", metrics)
    trainer.save_state()
    logger.info("Done")


if __name__ == '__main__':
    args = get_args(CONFIG_NAME)
    # config_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), args.config_path)
    main_train(args.config_path)
